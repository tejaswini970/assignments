package com.capgemini.mobipur.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.dao.IMobileDAO;
import com.capgemini.mobipur.dao.IpurchaseDetailsDAO;
import com.capgemini.mobipur.dao.MobileDAOImpl;
import com.capgemini.mobipur.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobipur.exception.MobilePurchaseException;


public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {
		int mobileQuantity = 0;
		boolean isItInserted = false;
		boolean isUpdated = false;
		IpurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOImpl();
		IMobileDAO mobileDAO = new MobileDAOImpl();

		mobileQuantity = mobileDAO.getQuantity(purchaseDetailsBean
				.getMobileId());
		if (mobileQuantity > 0) {
			isItInserted = purchaseDetailsDAO
					.insertPurchase(purchaseDetailsBean);
			mobileQuantity--;
			isUpdated = mobileDAO.updateMobile(
					purchaseDetailsBean.getMobileId(), mobileQuantity);
		}

		return (isItInserted && isUpdated);
	}

	public boolean isValidcName(String cname) throws MobilePurchaseException{
		boolean isValid = false;

		String pattern = "[A-z]{1}[A-Za-z]{1,19}";
		Pattern ptn=Pattern.compile(pattern);
        Matcher matcher= ptn.matcher(cname);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new MobilePurchaseException("Invalid name");
		}

		return isValid;
	}

	public boolean isValidPhoneNo(String phoneNo) throws MobilePurchaseException{
		boolean isValid = false;

		String pattern = "[\\d]{10}";

		Pattern ptn=Pattern.compile(pattern);
        Matcher matcher= ptn.matcher(phoneNo);
		isValid = matcher.matches();
		if(!isValid){
			throw new MobilePurchaseException("Phone number must contain atleast 10 digits");
		}

		return isValid;
	}
	public boolean isValidMail(String mail) throws MobilePurchaseException{
		boolean isValid = false;

		String pattern = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";

		Pattern ptn=Pattern.compile(pattern);
        Matcher matcher= ptn.matcher(mail);
		isValid = matcher.matches();		
		if(!isValid){
			throw new MobilePurchaseException("Invalid emailId");
		}

		return isValid;
	}
}
