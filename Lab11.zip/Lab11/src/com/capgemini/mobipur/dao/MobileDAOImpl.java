package com.capgemini.mobipur.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.mobipur.bean.Mobilebean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.util.DBConnection;

public class MobileDAOImpl implements IMobileDAO {

	@Override
	public boolean updateMobile(int mobileId, int quantity)
			throws MobilePurchaseException {
		int records=0;
		boolean isUpdated=false;
		try(Connection connmobiles = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
				connmobiles.prepareStatement(QueryMapperMobile.UPDATE_MOBILES)
		)
		{
		
			preparedStatement.setString(1,Integer.toString(quantity));
			preparedStatement.setInt(2,mobileId);
			records=preparedStatement.executeUpdate();
			if(records > 0)
			{
				isUpdated=true;
			}
		}
		catch(SQLException sqlEx)
		{
			throw new MobilePurchaseException(sqlEx.getMessage());
		}
		return isUpdated;
				
			
	}

	@Override
	public List<Mobilebean> viewAll() throws MobilePurchaseException {
		
		List<Mobilebean>mobilesList=new ArrayList<Mobilebean>();
		try(Connection connmobiles = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
				connmobiles.prepareStatement(QueryMapperMobile.VIEW_MOBILES);
				ResultSet rsMobiles=preparedStatement.executeQuery();
		)
		{
			
			while(rsMobiles.next()){
				Mobilebean mobile=new Mobilebean();
				
				mobile.setMobileId(rsMobiles.getInt("mobileid"));
				mobile.setName(rsMobiles.getString("name"));
				mobile.setPrice(rsMobiles.getInt("price"));
				mobile.setQuantity(rsMobiles.getString("quantity"));
				
				mobilesList.add(mobile);
			}
			if(mobilesList.size()==0){
				throw new MobilePurchaseException("No records found");
			}
		}
		catch(SQLException sqlEx)
		{
			throw new MobilePurchaseException(sqlEx.getMessage());
		}
		return mobilesList;
	}

	@Override
	public boolean deleteMobile(int mobileId) throws MobilePurchaseException {
		int records=0;
		boolean isDeleted=false;
		try(Connection connmobiles = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
				connmobiles.prepareStatement(QueryMapperMobile.DELETE_MOBILES)
		)
		{
			preparedStatement.setInt(1,mobileId);
			records=preparedStatement.executeUpdate();
			if(records > 0)
			{
				isDeleted=true;
			}
		}
		catch(SQLException sqlEx)
		{
			throw new MobilePurchaseException(sqlEx.getMessage());
		}
		return isDeleted;
	}

	@Override
	public List<Mobilebean> search(float minPrice, float maxPrice)
			throws MobilePurchaseException {
		List<Mobilebean>mobilesList=new ArrayList<Mobilebean>();
		try(Connection connmobiles = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
				connmobiles.prepareStatement(QueryMapperMobile.SEARCH_MOBILES);
				
		)
		{
			preparedStatement.setFloat(1,minPrice);
			preparedStatement.setFloat(2,maxPrice);
			ResultSet rsMobiles=preparedStatement.executeQuery();
			while(rsMobiles.next()){
				Mobilebean mobile=new Mobilebean();
				
				mobile.setMobileId(rsMobiles.getInt("mobileid"));
				mobile.setName(rsMobiles.getString("name"));
				mobile.setPrice(rsMobiles.getInt("price"));
				mobile.setQuantity(rsMobiles.getString("quantity"));
				
				mobilesList.add(mobile);
			}
			if(mobilesList.size()==0){
				throw new MobilePurchaseException("No records found");
			}
		}
		catch(SQLException sqlEx)
		{
			throw new MobilePurchaseException(sqlEx.getMessage());
		}
		return mobilesList;
	}

	@Override
	public int getQuantity(int mobileId) throws MobilePurchaseException {
		int mobileQty=0;
		try(Connection connmobiles = DBConnection.getInstance().getConnection();	
				
				PreparedStatement preparedStatement=
						connmobiles.prepareStatement(QueryMapperMobile.GET_MOBILES);
						
				)
				{
					preparedStatement.setInt(1,mobileId);
				
					ResultSet rsMobiles=preparedStatement.executeQuery();
					if(rsMobiles.next()){
						mobileQty = Integer.parseInt(rsMobiles.getString("quantity"));
					}
				}
				catch(SQLException sqlEx)
				{
					throw new MobilePurchaseException(sqlEx.getMessage());
				}
		return mobileQty;
	}

}
