package com.capgemini.mobipur.dao;

import com.capgemini.mobipur.bean.Mobilebean;
import com.capgemini.mobipur.exception.MobilePurchaseException;

import java.util.*;

public interface IMobileDAO {
	public boolean updateMobile(final int mobileId, final int quantity)
			throws MobilePurchaseException;

	public List<Mobilebean> viewAll() throws MobilePurchaseException;

	public boolean deleteMobile(int mobileId) throws MobilePurchaseException;

	public List<Mobilebean> search(final float minPrice, final float maxPrice)
			throws MobilePurchaseException;
    public int getQuantity(int mobileId) throws MobilePurchaseException;
}
