package com.capgemini.mobipur.exception;

public class MobilePurchaseException extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4473513424240627536L;

	public MobilePurchaseException()
	{
		super();
	}

	public MobilePurchaseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
