package com.cg.bmc.exception;

public class FirmException extends Exception{
	public FirmException(String errMsg) {
		super(errMsg);
	}
}
