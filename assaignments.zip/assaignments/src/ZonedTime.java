/*import java.util.Locale;
public class ZonedTime{
  public static void main(String... args) {
    ZoneId zone1 = ZoneId.of("Europe/Berlin");
    ZoneId zone2 = ZoneId.of("Brazil/East");

    Locale now1 = LocalTime.now(zone1);
    LocalTime now2 = LocalTime.now(zone2);

    System.out.println(now1);
    System.out.println(now2);

    System.out.println(now1.isBefore(now2));  // false

  }
}*/