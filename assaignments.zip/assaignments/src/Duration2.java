import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class Duration2 {
public static void main(String[] args) {
		
		SimpleDateFormat dateformat=new SimpleDateFormat("yyyy/MM/dd");
		System.out.print("Insert first date: ");
        Scanner s = new Scanner(System.in);
        String date1 = s.nextLine();
        System.out.print("Insert second date: ");
        String date2 = s.nextLine();
        long year,month,day;
        try
        {
        	Date newdate1=dateformat.parse(date1);
        	Date newdate2=dateformat.parse(date2);
        	//Date CurrDate=new Date();
        	
        	long diff=newdate1.getTime()-newdate2.getTime();
        	long diffInDays=(int)((diff)/(1000*60*60*24));
        	System.out.println("Difference in days:");
        	year = diffInDays / 365;
            diffInDays = diffInDays % 365;
            System.out.println("No. of years:"+year);
            month = diffInDays / 30;
            diffInDays = diffInDays % 30;
            System.out.println("No. of months:"+month);
            day = diffInDays;
            System.out.println("No. of days:"+day);
        }
        catch(ParseException e)
        {
        	e.printStackTrace();
        }
        s.close();
	}
}
