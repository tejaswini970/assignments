package Files;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;



public class DisplayEven {
	public static void main(String[] args) {

		try{
			File f=new File("number.txt"); 
			FileWriter write = new FileWriter(f);
			for(int i = 0; i <= 10; i++){
				write.append(i+",");
			}
			//write.append("10");
			write.close();
		}catch (IOException e) {
		      System.err.println(e);
	    }
		
		try{
			Scanner input = new Scanner(new File("number.txt"));
			input.useDelimiter("\\D");
			while(input.hasNextInt()){
				int next = input.nextInt();
				if(next%2==0){
					System.out.println(next);
				}
				
			}
		}catch (IOException e) {
		      System.err.println(e);
	    }
	}
}
