import java.util.Scanner;

public class StringOperatios {
	public static void main(String[] args) {
		String str;
		int num;
		Scanner scInput = new Scanner(System.in);
		System.out.println("Enter String:");
		str = scInput.nextLine();
		System.out.println("select the string operatio:");
		System.out.println("1.Add the String to itself");
		System.out.println("2.Replace odd positions with #");
		System.out.println("3.Remove duplicate characters in the String");
		System.out.println("4.Change odd characters to upper case");
		num = scInput.nextInt();
		switch (num) {
		case 1:
			strconcat(str);
			break;
		case 2:
			replace(str);
			break;
		case 3:
			removeduplicate(str);
			break;
		case 4:
			chageoddchar(str);
			break;
		default:
			System.out.println("plese select a valid case");
			break;
		}

		scInput.close();
	}

	private static void chageoddchar(String str) {
		
		String temp = "";
		String newstr = "";
		for (int i = 0; i < str.length(); i++) {
			if (i % 2 == 0) {
				temp = "";
				temp += str.charAt(i);
				temp = temp.toUpperCase();
				newstr += temp;
			} else {
				temp = "";
				temp += str.charAt(i);
				newstr += temp;
			}
		}
		System.out.println("new string is:" + newstr);
	}

	private static void replace(String str) {
		
		for (int i = 0; i < str.length(); i++) {
			if (i % 2 != 0) {
				str = str.substring(0, i - 1) + "#"
						+ str.substring(i, str.length());
			}
		}

		System.out.println(str);

	}

	public static void removeduplicate(String str) {
		
		char[] characters = str.toCharArray();
		boolean[] found = new boolean[256];
		StringBuilder sb = new StringBuilder();
		System.out.println("String with duplicates : " + str);
		for (char c : characters) {
			if (!found[c]) {
				found[c] = true;
				sb.append(c);
			}
		}
		System.out
				.println("String after duplicates removed : " + sb.toString());

	}

	private static void strconcat(String str) {
		
		StringBuilder sb = new StringBuilder(14);
		sb.append(str).append(" ").append(str);
		System.out.println(sb.toString());
	}

}
