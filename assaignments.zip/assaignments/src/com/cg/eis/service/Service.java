package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Service extends Employee implements EmployeeService {
	public Service(int id, String name, float salary, String designation,
			String insuranceScheme) {
		super(0, "", 0.0f, "", "");
	}

	public Employee getEmployeeDetails(Employee employee) {
		Scanner scInput = new Scanner(System.in);
		System.out.println("Enter employeee details:");
		System.out.println("Enter employee id:");
		employee.setId(scInput.nextInt());
		scInput.nextLine();
		System.out.println("Enter employee name:");
		employee.setName(scInput.nextLine());
		System.out.println("Enter Salary");
		employee.setSalary(scInput.nextFloat());
		scInput.nextLine();
		scInput.close();
		return employee;
	}

	public Employee findInsuranceScheme(Employee employee) {
		
		
		return employee;

	}




	public void display(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println("Id:"+employee.getId());
		System.out.println("Name:"+employee.getName());
		System.out.println("Salary:"+employee.getSalary());
		System.out.println("Designation:"+employee.getDesignation());
		System.out.println("InsuranceScheme:"+employee.getInsuranceScheme());
	}

	@Override
	public void Display(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	
}
