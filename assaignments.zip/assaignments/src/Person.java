
public class Person {
	String fname;
    String lname;
    char gender;
    String number;
	String dob;
	long age;
	String name;
	
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public long getAge() {
		return age;
	}
	public void setAge(long age) {
		this.age = age;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public Person() {
	}
	public Person(String fname, String lname, char gender,String number, String dob,long age,String name) {
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
		this.number=number;
		this.dob=dob;
		this.age=age;
		this.name=name;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public void output()
	{
		System.out.println("person details:");
		System.out.println("_______________");
		System.out.println("FirstName: "+fname);
		System.out.println("LastNmae: "+lname);
		System.out.println("Gender: "+gender);
		System.out.println("Phone Number: "+number);
		System.out.println("Date of Birth: "+dob);
		System.out.println("Age: "+age);
		System.out.println("FullName: "+name);
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
}
