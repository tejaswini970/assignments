package Employee;

import java.util.Scanner;

public class Details {
	static long constant = 1334556788;

	public static void main(String[] args) {
		int choice;
		double amount;
		Person accHolder[] = new Person[2];
		Account accHolder1[] = new Account[2];
		Account accHolder2[] = new SavingsAccount[2];
		Account accHolder3[] = new CurrentAccount[2];
		Scanner scInput = new Scanner(System.in);

		for (int i = 0; i < 2; i++) {
			accHolder[i] = new Person(null, 0);
			accHolder1[i] = new Account(0L, 0.0d);
			System.out.println("Enter First Name:");
			accHolder[i].name = scInput.next();

			System.out.println("Enter Age:");
			accHolder[i].age = scInput.nextInt();
			scInput.nextLine();
			accHolder1[i].accNum = constant + 3;

			System.out.println("Enter balance:");
			accHolder1[i].balance = scInput.nextDouble();
			System.out.println("Account details:");
			System.out.println("_______________");
			System.out.println("Account id to perform functions is "+i);
			System.out.println("Name: " + accHolder[i].name);
			System.out.println("Age: " + accHolder[i].age);
			System.out.println("Account Number: " + accHolder1[i].accNum);
			
		}
		System.out.println("select the account to which you want to perform a function");
		int j=scInput.nextInt();
		for(int i=j;i<2;i++)
		{
		System.out.println("select a function:");
		System.out.println("1.deposit");
		System.out.println("2.withdraw");
		choice = scInput.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter the amount to be deposited");
			amount=scInput.nextDouble();
			Account.deposit(accHolder1[i].balance,amount);
			break;
		case 2:
			System.out.println("Enter the amount to be withdrawn");
			amount=scInput.nextDouble();
			//Account.withdraw(accHolder1[i].balance,amount);
			System.out.println("select type of account");
			System.out.println("1.savings account");
			System.out.println("2.current account");
			int choice1;
			choice1=scInput.nextInt();
			if(choice1==1)
			{
			SavingsAccount.withdraw(accHolder1[i].balance,amount);
			}
			if(choice==2)
			{
			CurrentAccount.withdraw(accHolder1[i].balance,amount);
			}
			break;
		}
		}
		scInput.close();
	}

}
