package Employee;

public class SavingsAccount extends Account {
	final static long minbalance = 500;

	SavingsAccount(long balance) {
		super(0L, 0.0d);
	}
	
	public static void withdraw(double balance,double amount) {
		double  newbalance;
		
		if(balance>500)
		{
		if (amount < balance) {
			newbalance = balance - amount;
			System.out.println("your new balance is  " +newbalance);
		} else {
			System.out.println("your balance is only " + balance
					+ "\n withdrawal is not possible");
		}
		}
		else
		{
			System.out.println("your balance is below minimum balance withdrawl is not possible");
		}
	}
}
