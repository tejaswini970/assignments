package Employee;

public class Account {

	long accNum;
	double balance;

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Account(long accNum, double balance) {
		this.accNum = accNum;
		this.balance = balance;
	}

	public static void withdraw(double balance,double amount) {
		double  newbalance;
		
		if (amount < balance) {
			newbalance = balance - amount;
			System.out.println("your new balance is  " +newbalance);
		} else {
			System.out.println("your balance is only " + balance
					+ "\n withdrawal is not possible");
		}

	}

	public static void deposit(double balance,double amount) {

		double  newbalance;
		
		
		newbalance = balance + amount;
		System.out.println("your new balance is  " +newbalance);
	
	}

	
}
