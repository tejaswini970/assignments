
public class Details {
	String fname;
    String lname;
    char gender;
    int age;
    float weight ;
}
