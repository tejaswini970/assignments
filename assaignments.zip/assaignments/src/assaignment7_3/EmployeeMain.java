package assaignment7_3;

import java.util.Scanner;

public class EmployeeMain {
	public static void main(String[] args) {

		Scanner sc  = new Scanner(System.in);
		EmployeeServiceImpl empService = new EmployeeServiceImpl();
		
		while(true){
			
			System.out.println("1. Add Employee");
			System.out.println("2. Find Employee based on Insurance Scheme");
			System.out.println("3. Delete an Employee");
			System.out.println("4. Sort Employee Based on Salary and display");
			System.out.println("5. Quit");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
						sc.nextLine();
			if(choice==5){
				break;
			}
			switch(choice){
			case 1:
				System.out.println("Enetr id of the Employee: ");
				int id = sc.nextInt();
						sc.nextLine();
				System.out.println("Enter name of the Employee: ");
				String name = sc.nextLine();
				System.out.println("Enter salary of the Employee: ");
				long salary = sc.nextInt();
								sc.nextLine();
				
				Designation desig;
				InsuranceScheme insSch;
				
				if(salary>5000 && salary<20000){
					desig = Designation.System_Associate;
					insSch = InsuranceScheme.SchemeC;
				}else if(salary>=20000 && salary<40000){
					desig = Designation.Programmer;
					insSch = InsuranceScheme.SchemeB;
				}else if(salary>=40000){
					desig = Designation.Manager;
					insSch = InsuranceScheme.SchemeA;
				}else{
					desig = Designation.Clerk;
					insSch = InsuranceScheme.NoScheme;
				}
				
				Employee employee = new Employee(id,name,salary,desig,insSch);
				empService.addEmployee(employee);
				break;
			case 2:
				System.out.println("Enter Insurance Scheme: ");
				System.out.println("Enter 0 for Scheme C");
				System.out.println("Enter 1 for Scheme B");
				System.out.println("Enter 2 for Scheme A");
				System.out.println("Enter 3 for No Scheme");
				int select = sc.nextInt();
						sc.nextLine();
				if(select == 0){
					empService.find(InsuranceScheme.SchemeC);
				}else if(select == 1){
					empService.find(InsuranceScheme.SchemeB);
				}else if(select == 2){
					empService.find(InsuranceScheme.SchemeA);
				}else{
					empService.find(InsuranceScheme.NoScheme);
				}
								
				break;
			case 3:
				System.out.println("Enter id of the employee whose recorrd you want to delete: ");
				int idForDelete = sc.nextInt();
				
				boolean deleteStatus = empService.deleteEmployee(idForDelete);
				System.out.println(deleteStatus);
				break;
			case 4:
				empService.sortEmployee();
				break;
			}
		}
		
		
		sc.close();
	}

}
