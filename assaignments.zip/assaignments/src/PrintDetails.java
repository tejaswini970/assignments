
public class PrintDetails {
	public static void main(String[] args)
    {
		
        Details students[] = new Details[5];
        students[0] = new Details();
        students[0].fname = "Divya";
        students[0].lname = "Bharathi";
        students[0].gender = 'F';
        students[0].age = 20;
        students[0].weight =85.55f;
    
	
        System.out.println( "FirstName:"+students[0].fname+"\n"+"LastName:"+students[0].lname
        		+"\n"+"Gender:"+students[0].gender+"\n"+"Age:"+students[0].age+"\n"
        		+"Weight:"+students[0].weight);
    }
}