function validate(){
  var title = document.frmregistration.title.value;
var lname = document.frmregistration.lname.value;
	var name = document.frmregistration.fname.value;
	alert("All data for "+title+fname+lname" entered successfully.");
	}