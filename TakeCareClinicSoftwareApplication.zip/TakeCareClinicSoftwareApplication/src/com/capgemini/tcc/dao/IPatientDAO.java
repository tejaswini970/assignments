package com.capgemini.tcc.dao;

import java.util.List;

import com.capgemini.tcc.been.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public interface IPatientDAO {
	public String insertEmployee(final PatientBean patientBean) 
			throws PatientException;
	
	public List<PatientBean> search(final int empid)
			throws PatientException;
			
}
