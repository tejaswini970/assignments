package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.tcc.been.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.DBConnection;

public class PatientDAO implements IPatientDAO{

	public PatientDAO() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String insertEmployee(PatientBean patientBean)
			throws PatientException {
		int records=0;
		ResultSet resultSet = null;
		String patientId=null;
		
		try(Connection connPatientDetails = DBConnection.getInstance().getConnection();)	
		{
				PreparedStatement preparedStatement=
				connPatientDetails.prepareStatement(QueryMapperPatient.INSERT_PATIENT);
		
				java.sql.Date consultation_Date=new Date(new java.util.Date().getTime());
				
			
			
			preparedStatement.setString(1, patientBean.getPatient_Name());
			preparedStatement.setInt(2, patientBean.getAge());
			preparedStatement.setString(3, patientBean.getPhone());
			preparedStatement.setString(4, patientBean.getDescription());
			preparedStatement.setDate(5, consultation_Date);
			
			
			records=preparedStatement.executeUpdate();
			
			preparedStatement = connPatientDetails.prepareStatement(QueryMapperPatient.PATIENTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				patientId=resultSet.getString(1);
						
			}
	
			if(records==0)
			{
				throw new PatientException("Inserting Patient details failed ");

			}
			else
			{
				return patientId;
			}
			
		}
		catch(SQLException sqlEx)
		{
			throw new PatientException(sqlEx.getMessage());
		}
		
		
	}

	@Override
	public List<PatientBean> search(int patientid) throws PatientException {
		List<PatientBean> patientList = new ArrayList<PatientBean>();
		try(Connection connemp = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=connemp.prepareStatement(QueryMapperPatient.SEARCH_PATIENT);
							
				){
				preparedStatement.setInt(1, patientid);
			    ResultSet rsemps = preparedStatement.executeQuery();
				
			    while(rsemps.next()){
			    	PatientBean emp = new PatientBean();
				emp.setPatient_Id(rsemps.getInt("patient_id"));
				emp.setPatient_Name(rsemps.getString("patient_name"));
				emp.setAge(rsemps.getInt("age"));
				emp.setPhone(rsemps.getString("phone"));
				emp.setDescription(rsemps.getString("description"));
				emp.setConsultation_Date(rsemps.getDate("consultation_date"));
				
				patientList.add(emp);
			}
				if(patientList.size()==0){
					throw new PatientException("There is no patient with this ID");
				}
		}catch(SQLException sqlEx)
		{
			throw new PatientException(sqlEx.getMessage());
		}
		return patientList;
	}

}
