package com.cg.banking.service;

import java.util.List;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.exception.AccountException;

public interface IAccountService {
	List<BankingBean> getAccount(String customer_name) throws AccountException;
}
