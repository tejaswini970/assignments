package com.cg.banking.service;


import java.util.List;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.dao.AccountDAOImpl;
import com.cg.banking.dao.IAccountDAO;
import com.cg.banking.exception.AccountException;

public class AccountServiceImpl implements IAccountService {
	IAccountDAO dao = new AccountDAOImpl();
	@Override
	public List<BankingBean> getAccount(String customer_name) throws AccountException {
       
	
		return dao.getAccount(customer_name);
	}

}
