package com.cg.banking.dao;

public interface QueryMapperAccount {
	String VIEW = "SELECT account_number,customer_name,account_type,account_location,balance FROM account_details WHERE customer_name=?";

}
