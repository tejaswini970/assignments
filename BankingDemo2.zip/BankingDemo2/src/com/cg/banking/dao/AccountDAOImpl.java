package com.cg.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.exception.AccountException;
import com.cg.banking.util.DbConnection;



public class AccountDAOImpl implements IAccountDAO {

	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	
	@Override
	public List<BankingBean> getAccount(String customer_name) throws AccountException {
		
		List<BankingBean> list=new ArrayList<BankingBean>();
		
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapperAccount.VIEW);
			preparedStatement.setString(1, customer_name);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				
				BankingBean bb=new BankingBean();
				bb.setAccount_number(resultSet.getString(1));
				bb.setCustomer_name(resultSet.getString(2));
				bb.setAccount_type(resultSet.getString(3));
				bb.setAccount_location(resultSet.getString(4));
				bb.setBalance(resultSet.getFloat(5));
				list.add(bb);
				
			}

		} catch (SQLException e) {
			throw new AccountException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new AccountException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new AccountException(
						"Could not close the connection");
			}
		}
		return list;
	
	}

}
