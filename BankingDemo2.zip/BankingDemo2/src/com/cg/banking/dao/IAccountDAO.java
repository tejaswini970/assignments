package com.cg.banking.dao;

import java.util.List;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.exception.AccountException;




public interface IAccountDAO {

	  
	List<BankingBean> getAccount(String customer_name) throws AccountException;
}
