package com.cg.banking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import com.cg.banking.bean.BankingBean;
import com.cg.banking.exception.AccountException;
import com.cg.banking.service.AccountServiceImpl;



/**
 * Servlet implementation class Account
 */
@WebServlet("*.obj")
public class Account extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Account() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AccountServiceImpl accountService = null;
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		List<BankingBean> list = new ArrayList<BankingBean>();
		String target = null;

		
		
		accountService = new AccountServiceImpl();
		
		String customer_name=null;
		
		String targetView = "viewAccount.jsp";
		String targetSearch="search.jsp";
		String targetError = "error.jsp";
		String path = request.getServletPath().trim();
		
		switch (path) {
		
		
		case "/viewAccount.obj" :
			
			target = targetView;
			break;
		case "/search.obj" :
			customer_name = request.getParameter("customer_name");
			try {
				list= accountService.getAccount(customer_name);
				request.setAttribute("accountlist",list);
				target = targetSearch;
		
			} catch (AccountException e) {
				request.setAttribute("error", e.getMessage());
				target = targetError;
			}
			
			break;

		
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

}
