package com.employee.bean;

public class EmployeeBean {
	private int employeeid;
	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	private String name;
	private int salary;
	String doj;
	private String dname;
	private String designation;
	
	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public EmployeeBean() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public EmployeeBean(int employeeid,String name, int salary, String doj, String dname,
			String designation) {
		super();
		this.employeeid=employeeid;
		this.name = name;
		this.salary = salary;
		this.doj = doj;
		this.dname = dname;
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "EmployeeBean [employeeid=" + employeeid + ", name=" + name
				+ ", salary=" + salary + ", doj=" + doj + ", dname=" + dname
				+ ", designation=" + designation + "]";
	}

	
	

	
}
