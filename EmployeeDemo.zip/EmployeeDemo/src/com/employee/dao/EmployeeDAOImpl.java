package com.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.List;

import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;
import com.employee.util.DBConnection;

public class EmployeeDAOImpl implements IEmployeeDAO {

	@Override
	public String insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		int records=0;
		ResultSet resultSet = null;
		String empId=null;
		
		try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();)	
		{
				PreparedStatement preparedStatement=
				connEmployeeDetails.prepareStatement(QueryMapperEmployee.INSERT_EMPLOYEE);
		
			
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			
			String strDate=employeeBean.getDoj();
			
			TemporalAccessor ta=dtf.parse(strDate);
			
			LocalDate localDate=LocalDate.from(ta);
			
			java.sql.Date doj=java.sql.Date.valueOf(localDate);
			
			preparedStatement.setString(1, employeeBean.getName());
			preparedStatement.setDate(2, doj);
			preparedStatement.setInt(3, employeeBean.getSalary());
			preparedStatement.setString(4, employeeBean.getDname());
			preparedStatement.setString(5, employeeBean.getDesignation());
			
			
			records=preparedStatement.executeUpdate();
			
			preparedStatement = connEmployeeDetails.prepareStatement(QueryMapperEmployee.EMPID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				empId=resultSet.getString(1);
						
			}
	
			if(records==0)
			{
				throw new EmployeeException("Inserting Employee details failed ");

			}
			else
			{
				return empId;
			}
			
		}
		catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		
		
		
	}

	@Override
	public boolean deleteEmployee(int empId) throws EmployeeException {
		int records=0;
		boolean isDeleted=false;
		
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
				connPurchaseDetails.prepareStatement(QueryMapperEmployee.DELETE_EMPLOYEE);)
		{
						
			preparedStatement.setInt(1, empId);
			
			records=preparedStatement.executeUpdate();
			
			if(records>0)
				isDeleted=true;
			
		}
		catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		
		return isDeleted;
	}

	@Override
	public boolean updateEmployee(int empId, int salary)
			throws EmployeeException {
		int records=0;
		boolean isUpdated=false;
		
		try(Connection connMobile = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
				connMobile.prepareStatement(QueryMapperEmployee.UPDATE_EMPLOYEE);)
		{
			
			preparedStatement.setInt(1, salary);
			preparedStatement.setInt(2, empId);
			
			records=preparedStatement.executeUpdate();
			
			if(records>0)
				isUpdated=true;
			
		}
		catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		
		return isUpdated;
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeeException {
		
		List<EmployeeBean>employeeList=new ArrayList<EmployeeBean>();
		
		try(Connection connemployee = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=
				connemployee.prepareStatement(QueryMapperEmployee.VIEW_EMPLOYEE);
				ResultSet rsEmployees=preparedStatement.executeQuery();
		)
		{
			
			while(rsEmployees.next()){
				EmployeeBean employee=new EmployeeBean();
				
				employee.setEmployeeid(rsEmployees.getInt("employeeid"));
				employee.setName(rsEmployees.getString("employeename"));
				employee.setSalary(rsEmployees.getInt("salary"));
				employee.setDoj(rsEmployees.getString("hiredate"));
				employee.setDname(rsEmployees.getString("departmentname"));
				employee.setDesignation(rsEmployees.getString("designation"));
				
				employeeList.add(employee);
			}
			if(employeeList.size()==0){
				throw new EmployeeException("No records found");
			}
		}
		catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		return employeeList;
	}

	
}
