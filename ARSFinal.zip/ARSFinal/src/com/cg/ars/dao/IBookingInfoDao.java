/**
 * 
 */
package com.cg.ars.dao;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;


/**
 * @author CAPG
 *
 */
public interface IBookingInfoDao {

	BookingInformationBean confirmBooking(BookingInformationBean bookingInformationBean, FlightInformationBean flightInformationBean) throws ARSException;

	void displayBooking(BookingInformationBean bookingInformationBean) throws ARSException;

	void cancelBooking(BookingInformationBean bookingInformationBean,FlightInformationBean flightInformationBean) throws ARSException;
}
