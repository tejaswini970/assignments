/**
 * 
 */
package com.cg.service;

import com.cg.ars.exception.ARSException;

/**
 * @author CAPG
 *
 */
public interface IUserService {

	public boolean isValidUser(String userName, String password, String role)
			throws ARSException;

}
